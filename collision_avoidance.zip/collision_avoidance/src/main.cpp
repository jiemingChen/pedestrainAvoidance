//
// Created by jieming on 28.04.20.
//
//
#include <gazebo_msgs/GetModelState.h>
#include <geometry_msgs/Pose.h>
#include "collision_avoidance/header.h"
#include "Config.h"
#include <chrono>
#include <thread>
#include "solver.h"
#include "PID.h"

//  marker id  obstacles0-20, mc horizion, -------  terminal point 1000
void pubTerminal( const ros::Publisher& vis_pub,  vector<double> terminal){
    visualization_msgs::Marker marker;
    marker.header.frame_id = "odom";
    marker.header.stamp = ros::Time();
    marker.ns = "/";
    marker.id = 1000;
    marker.type = visualization_msgs::Marker::CUBE;
    marker.pose.position.x = terminal[0];
    marker.pose.position.y = terminal[1];
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.5;
    marker.scale.y = 0.4;
    marker.scale.z = 0.3;
    marker.color.a = 0.5;
    marker.color.r = 0.0;
    marker.color.g = 0.0;
    marker.color.b = 1.0;
    vis_pub.publish( marker );
}

void pubObstacles( const ros::Publisher&  marker_array_pub,  vector<vector<float>> obstacles){
    visualization_msgs::MarkerArray array;
    array.markers.clear();
    visualization_msgs::Marker  marker;
    for(auto i=0; i<obstacles.size(); i++){
        marker.header.frame_id = "odom";
        marker.header.stamp = ros::Time();
        marker.ns = "/";
        marker.id = obstacles[i][2];
        marker.type = visualization_msgs::Marker::CUBE;
        marker.action = visualization_msgs::Marker::ADD;
        marker.pose.position.x = obstacles[i][0];
        marker.pose.position.y = obstacles[i][1];
        marker.pose.position.z = 0;

        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;
        marker.scale.x = 0.2;
        marker.scale.y = 0.2;
        marker.scale.z = 0.2;
        marker.color.a = 0.5;
        marker.color.r = 1.0;
        marker.color.g = 0.0;
        marker.color.b = 0.0;

        array.markers.push_back(marker);
    }
    for(auto i=0; i<obstacles.size(); i++){
        marker.header.frame_id = "odom";
        marker.header.stamp = ros::Time();
        marker.ns = "/";
        marker.id = obstacles[i][2]+obstacles.size();
        marker.type = visualization_msgs::Marker::CYLINDER;
        marker.action = visualization_msgs::Marker::ADD;
        marker.pose.position.x = obstacles[i][0];
        marker.pose.position.y = obstacles[i][1];
        marker.pose.position.z = 0;
        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;
        marker.scale.x = Config::get<float>("safe_dist")*2;
        marker.scale.y = Config::get<float>("safe_dist")*2;
        marker.scale.z = 0.1;
        marker.color.a = 0.3;
        marker.color.r = 1.0;
        marker.color.g = 0.0;
        marker.color.b = 0.0;

        array.markers.push_back(marker);
    }

    marker_array_pub.publish(array);
}

void pubTraj(const ros::Publisher& vis_pub, int idx, vector<float>state){
    visualization_msgs::Marker marker;
    marker.header.frame_id = "odom";
    marker.header.stamp = ros::Time();
    marker.ns = "/";
    marker.id = idx;
    marker.type = visualization_msgs::Marker::ARROW;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.x = state[0];
    marker.pose.position.y = state[1];
    marker.pose.position.z = 0;

    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.1;
    marker.scale.y = 0.1;
    marker.scale.z = 0.1;
    marker.color.a = 0.5;
    marker.color.r = 0.0;
    marker.color.g = 1.0;
    marker.color.b = 0.0;
    vis_pub.publish( marker );
}

void pubTraj2(const ros::Publisher& marker_array_pub,  vector<float>&state){
    visualization_msgs::MarkerArray array;
    array.markers.clear();
    visualization_msgs::Marker  marker;

    Eigen::AngleAxisf rollAngle(0, Eigen::Vector3f::UnitX());
    Eigen::AngleAxisf pitchAngle(0, Eigen::Vector3f::UnitY());
    Eigen::AngleAxisf yawAngle(0, Eigen::Vector3f::UnitZ());
    Eigen::Quaternionf q;
    auto n = Config::get<float>("N_");
    for(auto i=0; i<state.size()/3; i++){
        marker.header.frame_id = "odom";
        marker.header.stamp = ros::Time();
        marker.ns = "/";
        marker.id = 20+i;
        marker.type = visualization_msgs::Marker::ARROW;
        marker.action = visualization_msgs::Marker::ADD;
//        marker.pose.position.x = state[2+i*3];
//        marker.pose.position.y = state[3+i*3];
        marker.pose.position.x = state[i*3];
        marker.pose.position.y = state[1+i*3];
        marker.pose.position.z = 0;

//        yawAngle.angle() = state[4+i*3];
        yawAngle.angle() = state[2+i*3];
        q = yawAngle * pitchAngle * rollAngle;
        marker.pose.orientation.x = q.x();
        marker.pose.orientation.y = q.y();
        marker.pose.orientation.z = q.z();
        marker.pose.orientation.w = q.w();
        marker.scale.x = 0.4;
        marker.scale.y = 0.4;
        marker.scale.z = 0.4;
        marker.color.a = 0.5;
        marker.color.r = 0.0;
        marker.color.g = 1.0;
        marker.color.b = 0.0;

        array.markers.push_back(marker);
    }
    marker_array_pub.publish(array);
}

void pubCommand(const ros::Publisher& cmd_pub, const vector<float>& data){
    geometry_msgs::Twist cmd;
//    std::cout<<data[0]<<"!!!!!!!!!!!!!!!"<<std::endl;

    cmd.linear.x = data[0];
    cmd.linear.y = 0;
    cmd.linear.z = 0;
    cmd.angular.x = 0;
    cmd.angular.y = 0;
    cmd.angular.z = -data[1];
    cmd_pub.publish(cmd);
}

vector<float> getCurrentPos(tf::TransformListener& listener){
    tf::StampedTransform transform;
    vector<float> rst;

    try{
        listener.lookupTransform("odom", "front_steering", ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
        ROS_ERROR("%s wocao",ex.what());
        ros::Duration(1.0).sleep();
    }
    rst.push_back(transform.getOrigin().x());
    rst.push_back(transform.getOrigin().y());

    try{
        listener.lookupTransform("odom", "base_link", ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
        ROS_ERROR("%s  nimade",ex.what());
        ros::Duration(1.0).sleep();
    }
    auto quaternion  = transform.getRotation();
    float angle = atan2(2*(quaternion.w()*quaternion.z()+quaternion.x()*quaternion.y()), 1-2*(pow(quaternion.y(),2)+pow(quaternion.z(),2)));
    if(angle>M_PI){
        angle = angle - 2*M_PI;
    }
    rst.push_back(angle);
    return rst;
}

std::pair<std::vector<std::vector<float>>,std::vector<std::vector<float>>> getPeopleInfo(ros::NodeHandle& n, std::vector<std::string> names){
    ros::ServiceClient client = n.serviceClient<gazebo_msgs::GetModelState>("/gazebo/get_model_state");
    ros::ServiceClient client_v1 = n.serviceClient<actor_plugin::GetVel>("/actor1/GetActorVelocity");
    ros::ServiceClient client_v2 = n.serviceClient<actor_plugin::GetVel>("/actor2/GetActorVelocity");

    gazebo_msgs::GetModelState srv;
    actor_plugin::GetVel srv2;

    ros::Rate r(40);
    std::vector<std::vector<float>> poses;
    std::vector<std::vector<float>> speed;

    int i =0;

    for(const auto& name:names){
        srv.request.model_name=name;
        srv2.request.set_flag = false;
        srv2.response.x = 0;
        srv2.response.y= 0;

        if(client.call(srv)){
            auto pos = srv.response.pose;
//            ROS_INFO("%s is here %f, %f", name.c_str(), pos.position.x, pos.position.y);
            std::vector<float> temp(3,0);
            temp[0] = static_cast<float>(pos.position.x);
            temp[1] = static_cast<float>(pos.position.y);
            temp[2] = i;
            poses.push_back(temp);
        }

        if(name=="actor1"){

            client_v1.call(srv2);
            std::vector<float> temp(2,0);
            temp[0] = srv2.response.x;
            temp[1] = srv2.response.y;
            temp[1] = 0;
            speed.push_back(temp);
//            ROS_INFO("%s is here %f, %f", name.c_str(), temp[0], temp[1]);
        }
        else if(name=="actor2"){
            client_v2.call(srv2);
            std::vector<float> temp(2,0);
            temp[0] = srv2.response.x;
            temp[1] = srv2.response.y;
            temp[0] = 0;
            speed.push_back(temp);
//            ROS_INFO("%s is here %f, %f", name.c_str(), temp[0], temp[1]);
        }
        else{
            std::vector<float> temp(2,0);
            speed.push_back(temp);
        }

        i++;
        r.sleep();
    }
    auto rst = std::make_pair(poses, speed);
    return rst;
}

std::pair<std::vector<std::vector<float>>,std::vector<std::vector<float>>> findNearObstacles(const std::pair<std::vector<std::vector<float>>,std::vector<std::vector<float>>>& obstacles, const vector<float>& current_state){
    float distance;
    vector<vector<float>> near_obstacles, near_obstacles_v;

    for(auto i=0; i<obstacles.first.size(); i++){
        distance = pow(obstacles.first[i][0]-current_state[0], 2) + pow(obstacles.first[i][1]-current_state[1],2);
        if(distance <= pow(5,2)){
            near_obstacles.push_back(obstacles.first[i]);
            near_obstacles_v.push_back(obstacles.second[i]);
        }
    }

    auto rst = std::make_pair(near_obstacles, near_obstacles_v);
    return rst;
}
#if 1
// mpc
int main(int argc,char **argv){

    ros::init(argc,argv,"collision_avoidance_node");
    ros::NodeHandle n;
    ros::Publisher vis_pub =  n.advertise<visualization_msgs::Marker>( "visualization_marker", 10);
    ros::Publisher marker_array_pub =  n.advertise<visualization_msgs::MarkerArray>( "visualization_marker_array", 10);
    ros::Publisher cmd_pub = n.advertise<geometry_msgs::Twist>("cmd_vel",4);
    tf::TransformListener listener;
    ros::Rate r(10);

    std::vector<std::string> names = {"xiaomei","dahei",  "jams", "actor1", "actor2"};
//    std::vector<std::string> names = {"actor1", "actor2", "xiaomei", "dahei" , "jams"};
//    std::vector<std::string> names = { "xiaomei", "dahei" , "jams"};

    std::pair<std::vector<std::vector<float>>,std::vector<std::vector<float>>> obstacles;

    Config::setParameterFile("/home/jieming/car_ws/src/collision_avoidance/config/default.yaml");
//    std::vector<float> start_point = {Config::get<float>("xStart"), Config::get<float>("yStart")};  // 改为odom位置
//    start_point.push_back(-2);

    std::vector<double> target_point = {Config::get<float>("xTarget"), Config::get<float>("yTarget"), 0};

//    target_point.push_back(atan2(target_point[1]-start_point[1], target_point[0]-start_point[0]));
    int N_sim = Config::get<int>("N_sim");

    std::pair<vector<double>, vector<float>> job_point;
    vector<float> current_state;
    job_point.first = vector<double>(3,0);
    job_point.second = vector<float>(2,0);

    ros::spinOnce();
    r.sleep();
    pubTerminal(vis_pub, target_point);


    Solver solver;
//    current_state = getCurrentPos(listener);
//    job_point.first[2] = current_state[2];

    std::chrono::milliseconds delta_time;
    for(auto t=0; t<N_sim; t++){

        obstacles = getPeopleInfo(n, names);
        pubObstacles(marker_array_pub, obstacles.first);

        current_state = getCurrentPos(listener);
        double angle = atan2(target_point[1]-current_state[1], target_point[0]-current_state[0]);
//        cout<<angle<< "~~!!!!! " << endl;
        if(abs(angle-current_state[2])>1.45){
            job_point.first[2] = current_state[2];
        }
        else{
            job_point.first[2] = angle;
        }
//        job_point.first[2] = angle;

        target_point[2] = atan2(target_point[1]-current_state[1], target_point[0]-current_state[0]);

        if(pow(current_state[0]-target_point[0],2)+pow(current_state[1]-target_point[1],2) <= pow(0.3,2)){
            cout<<"arrive"<<endl;
            vector<float> temp={0,0};
            pubCommand(cmd_pub, temp);
            break;
        }

        auto near_obstacles = findNearObstacles(obstacles, current_state);
        auto solver_solution = solver.solve2(job_point, target_point, current_state, near_obstacles);

        // for test------------
//        solver_solution[0]=0;
//        solver_solution[1]=0;
        //--------------------
//        pubCommand(cmd_pub, solver_solution);
        pubTraj2(marker_array_pub, solver_solution);

        ros::spinOnce();
        r.sleep();
        job_point.second[0] = 0.9;

    }

    return 0;
}
#endif

#if 0
// tube mpc
int main(int argc,char **argv){

    ros::init(argc,argv,"collision_avoidance_node");
    ros::NodeHandle n;
    ros::Publisher vis_pub =  n.advertise<visualization_msgs::Marker>( "visualization_marker", 10);
    ros::Publisher marker_array_pub =  n.advertise<visualization_msgs::MarkerArray>( "visualization_marker_array", 2);
    ros::Publisher cmd_pub = n.advertise<geometry_msgs::Twist>("cmd_vel",4);
    tf::TransformListener listener;
    ros::Rate r(10);

//    std::vector<std::string> names = {"xiaomei","dahei",  "jams", "zhongbai", "actor1", "actor2"};
    std::vector<std::string> names = {"actor1", "actor2", "xiaomei", "dahei"};
    std::pair<std::vector<std::vector<float>>,std::vector<std::vector<float>>> obstacles;

    Config::setParameterFile("/home/jieming/car_ws/src/collision_avoidance/config/default.yaml");

    std::vector<float> target_point = {Config::get<float>("xTarget"), Config::get<float>("yTarget"), 0};

    int N_sim = Config::get<int>("N_sim");

    std::pair<vector<float>, vector<float>> job_point;
    vector<float> current_state;
    job_point.first = vector<float>(3,0);
    job_point.second.push_back(0.3);
    job_point.second.push_back(0);

    ros::spinOnce();
    r.sleep();
    pubTerminal(vis_pub, target_point);
    PID pid;

    Solver solver;
    for(auto t=0; t<N_sim; t++){
        obstacles = getPeopleInfo(n, names);
        pubObstacles(marker_array_pub, obstacles.first);

        current_state = getCurrentPos(listener);
        target_point[2] = atan2(target_point[1]-current_state[1], target_point[0]-current_state[0]);

        float angle = atan2(target_point[1]-current_state[1], target_point[0]-current_state[0]);
        if(abs(angle-current_state[2])>1.3){
            job_point.first[2] = current_state[2];
        }
        else{
            job_point.first[2] = angle;
        }
//        job_point.first[2] = angle;

        if(pow(current_state[0]-target_point[0],2)+pow(current_state[1]-target_point[1],2) <= pow(0.3,2)){
            cout<<"arrive"<<endl;
            vector<float> temp={0,0};
            pubCommand(cmd_pub, temp);
            break;
        }

        auto near_obstacles = findNearObstacles(obstacles, current_state);

        /// \brief mpc give reference
        auto solver_solution = solver.solve2(job_point, target_point, current_state, near_obstacles);
        auto next_state = solver.nominalSystem(solver_solution, current_state);

        /// \brief pid  cope with uncertainty, disturbance
        float vertical_error = 1000;
        pid.initialize(next_state, current_state);
        while(1){
            auto error = pow(pow(next_state[0]-current_state[0],2)+pow(next_state[1]-current_state[1],2),2);
            if( error<=0.15*0.15 && vertical_error<=0.1){
//                pubCommand(cmd_pub, vector<float>(2,0));
                break;
            }
            vertical_error = pid.control(next_state, current_state, solver_solution);

            pubCommand(cmd_pub, solver_solution);
            pubTraj2(marker_array_pub, solver_solution);
            ros::spinOnce();
            r.sleep();
            current_state = getCurrentPos(listener);
        }


//        pubTraj2(marker_array_pub, solver_solution);
        ros::spinOnce();
        r.sleep();

    }

    return 0;
}
#endif



#if 0
int main(int argc,char **argv){

    ros::init(argc,argv,"collision_avoidance_node");
    ros::NodeHandle n;
    ros::Publisher vis_pub =  n.advertise<visualization_msgs::Marker>( "visualization_marker", 10);
    ros::Publisher marker_array_pub =  n.advertise<visualization_msgs::MarkerArray>( "visualization_marker_array", 2);
    ros::Publisher cmd_pub = n.advertise<geometry_msgs::Twist>("cmd_vel",4);
    tf::TransformListener listener;
    ros::Rate r(20);
    ros::spinOnce();
    r.sleep();

    Config::setParameterFile("/home/jieming/car_ws/src/collision_avoidance/config/default.yaml");
    std::vector<double> target_point = {Config::get<double>("xTarget"), Config::get<double>("yTarget"), M_PI};
    PID pid;
    vector<float> solver_solution={1,0};
    float steer_error=1000;
    auto current_state = getCurrentPos(listener);
    ros::spinOnce();
    r.sleep();
    pid.initialize(target_point, current_state);
    while(1){
         current_state = getCurrentPos(listener);
         ros::spinOnce();
        r.sleep();
        float rst= pow(target_point[0]-current_state[0],2) + pow(target_point[1]-current_state[1],2);
        if(rst<=0.2*0.2 && steer_error<0.2){
            break;
        }
         steer_error = pid.control(target_point, current_state, solver_solution);

        pubCommand(cmd_pub, solver_solution);
        pubTraj2(marker_array_pub, solver_solution);
        ros::spinOnce();
        r.sleep();
    }
    cout<<"arrive"<<endl;
    vector<float> temp={0,0};
    pubCommand(cmd_pub, temp);
    ros::spinOnce();
    r.sleep();
    return 0;
}
#endif
////       std::this_thread::sleep_for(std::chrono::seconds(5));
