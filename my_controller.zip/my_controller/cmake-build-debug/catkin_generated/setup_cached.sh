#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/jieming/car_ws/src/my_controller/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export PATH="/opt/ros/melodic/bin:/opt/clion-2019.1.4/bin:/usr/local/cuda/bin:.:/opt/java-se-8u40-ri/bin:/home/jieming/miniconda3/bin:/home/jieming/miniconda3/condabin:/home/jieming/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
export ROSLISP_PACKAGE_DIRECTORIES="/home/jieming/car_ws/src/my_controller/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/jieming/car_ws/src/my_controller:/home/jieming/catkin_ws/src:/opt/ros/melodic/share"